import React from "react";
const Footer = () => {
  return <footer>Created by AdrianTech 2019 - 2020</footer>;
};
export default Footer;
