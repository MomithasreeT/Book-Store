### Technology stack
 - HTML
 - SCSS
 - React.js
 - React-Router
 - React Hooks
 - Context API
 
 Note: This project is still open
 
#### Description
A bit of Bookstore with dummy API. The Main functions allows us to add and remove book from the cart. Check this out by clicking the link below.
#### [BookStore](https://oldtown.netlify.com/)
